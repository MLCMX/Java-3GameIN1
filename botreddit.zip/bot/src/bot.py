"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Yousef EL-Qawasmi
ID:          190615960
Email:   elqa5960@mylaurier.ca
__updated__ = "2019-10-05"
-------------------------------------------------------
"""
# Imports
import praw
from spellcheck import is_spelled_correctly
# Constants
reddit = praw.Reddit(client_id='',
                            client_secret="", password='',
                            user_agent='', username='')
subreddit= reddit.subreddit("terminal")
for comment in subreddit.stream.comments():
    #print(comment.body)
    c = (comment.body)
    hasWrong = False
    s = ""
    if "u/Botferguson" in comment.body:
        all_words = c.split(" ")
        for word in all_words:
            if not is_spelled_correctly(word):
                if(word != "u/Botferguson"):
                    s = s + word + ", "
                    hasWrong = True
    if(hasWrong):
        print(s + "are all spelled incorrectly.")
"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Yousef EL-Qawasmi
ID:          190615960
Email:   elqa5960@mylaurier.ca
__updated__ = "2019-10-05"
-------------------------------------------------------
"""
# Imports

# Constants
dictionary = set()

def read_dictionary_file():
    global dictionary
    if dictionary:
        return
    with open ("words.txt","r") as f:
        contents = f.read()
        
    dictionary = set(
        word.lower()
        for word in contents.splitlines()
    )


def is_spelled_correctly(word):
    word = word.lower()
    read_dictionary_file()
    return word in dictionary
        